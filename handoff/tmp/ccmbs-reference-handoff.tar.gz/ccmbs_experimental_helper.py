"""Temporary CAMB reference inputs for declared nonstandard radiation."""
import math
import os
from scipy.integrate import quad
from tests.project.lib import camb_reference
_original = camb_reference._make_camb_params

def _make_params(contract, *, lmax=None):
    params = _original(contract, lmax=lmax)
    if 'CCMBS_CAMB_REFERENCE_OMEGA_GAMMA' not in os.environ:
        return params
    values = contract['param_map']
    mass = float(values.get('sum_mnu', values.get('mnu', 0.0)))
    count = int(values.get('num_massive_neutrinos', 0))
    if mass > 0 and count > 0:
        photon = float(os.environ['CCMBS_CAMB_REFERENCE_OMEGA_GAMMA'])
        neff = float(values['Neff'])
        temperature = float(params.TCMB)*(4.0/11.0)**(1.0/3.0)*8.617333262145e-5
        mass_ratio = mass/count/temperature
        integral = quad(lambda q: q*q*math.hypot(q,mass_ratio)*math.exp(-q)/(1+math.exp(-q)), 0, math.inf, epsabs=1e-10, epsrel=1e-11)[0]
        massless = 7*math.pi**4/120
        relativistic = (7/8)*(4/11)**(4/3)*photon*min(neff,count)
        params.omnuh2 = relativistic*integral/massless*(params.H0/100)**2
    if os.environ.get('CCMBS_CAMB_REFERENCE_PPF_DE') == '1':
        component = params.DarkEnergy
        params.set_dark_energy(w=component.w, wa=component.wa, cs2=component.cs2, dark_energy_model='ppf')
    return params
camb_reference._make_camb_params = _make_params
