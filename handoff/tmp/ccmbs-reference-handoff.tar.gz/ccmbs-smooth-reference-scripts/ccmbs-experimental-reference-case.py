import hashlib,json,logging,os,platform,subprocess,sys,time
import scipy
from pathlib import Path
import numpy as np
from tests.copernican.lib.test_model_adapter import DeclaredLCDMModelTestCase
from copernican.lib.likelihoods.cmb.runtime import background,evolution
from tests.project.lib import scientific_acceptance as acceptance,camb_reference
import ccmbs_experimental_helper
logging.disable(logging.CRITICAL)
filename,point,recombination,reionization,output=sys.argv[1:]
plugin=DeclaredLCDMModelTestCase._build_plugin(filename)
runtime=acceptance.completion_point_contract(plugin,point)
if acceptance.diagnostics._canonical_sha256(runtime['background']['reionization']) != '124f136ceaef2c0f0f2724ffafa3874b944c29963d7e31a58c0271fccc82254d':
 raise ValueError('Independent reference does not implement this reionization law')
if runtime['background'].get('recombination'):
 raise ValueError('Independent reference does not implement this recombination declaration')

physical=background._resolve_custom_cmb_physical_parameters(runtime)
os.environ['CCMBS_CAMB_REFERENCE_OMEGA_GAMMA']=str(physical.Omega_gamma0)
os.environ['CCMBS_CAMB_REFERENCE_SMOOTH_DE']='1'
os.environ['CCMBS_CAMB_REFERENCE_RECOMB_TABLE']=recombination
os.environ['CCMBS_CAMB_REFERENCE_REION_TABLE']=reionization
contract=acceptance.completion_reference_contract(runtime,canonical_defaults=True)
params=camb_reference._make_camb_params(contract)
independent=camb_reference.camb.get_background(params)
z=np.unique(np.concatenate((np.linspace(0,25,251),np.linspace(25,2500,500))))
other=independent.get_background_redshift_evolution(z,vars=('x_e','T_b','opacity'))
ref_h=independent.hubble_parameter(z)
resolved=background._resolve_declared_background_context(runtime,a_values=1/(1+z),z_values=z)
native=background._build_custom_cmb_background_impl(runtime,physical,background._CustomCMBNumerics(eta_sample_count=8192))
eta=native.eta_of_a(1/(1+z))
native_xe=native.x_e_of_eta(eta)
native_temperature=native.matter_temperature_of_eta(eta)
H_error=float(np.max(abs(np.asarray(resolved['H'])/ref_h-1)))
q=evolution._declared_momentum_grid_context(runtime['perturbation_data'],model_parameters=background._momentum_model_parameters(runtime),physical_params=physical,scale_factor=1/(1+z))
actual_neutrinos=np.asarray(q['massive_neutrino_density_fraction'])+float(resolved['Omega_nu_massless0'])*(1+z)**4
reference_neutrinos=np.array([independent.get_Omega('nu',float(item))+independent.get_Omega('neutrino',float(item)) for item in z])*(ref_h/physical.H0_km_s_Mpc)**2
neutrino_error=float(np.max(abs(actual_neutrinos/reference_neutrinos-1)))
xe_abs=float(np.max(abs(native_xe-other['x_e'])))
xe_scale=xe_abs/max(float(np.max(abs(other['x_e']))),np.finfo(float).tiny)
xe_recombination=float(np.max(abs(native_xe[z>=25]/other['x_e'][z>=25]-1)))
temperature_error=float(np.max(abs(native_temperature/other['T_b']-1)))
if H_error > 0.0002 or xe_scale > 0.005 or xe_recombination > 0.001 or temperature_error > 0.005 or neutrino_error > 0.001:
 raise ValueError(f'History mismatch: H={H_error}, xe={xe_scale}, recomb={xe_recombination}, T={temperature_error}')
requirement=json.loads(Path('tests/project/fixtures/ccmbs_completion_contract.json').read_text())['cases'][filename+':'+point]
start=time.monotonic()
fixture=camb_reference.build_camb_full_reference_fixture(contract,range(2,2501),model_name=filename,fixed_point=point,spectra=tuple(name for name in camb_reference.CAMB_PARITY_SPECTRA if name in requirement['surfaces']))
fixture['features']=camb_reference.completion_reference_windows(fixture)
fixture['damping_windows']=requirement['damping_windows']
fixture['resolved_defaults']=str(camb_reference._make_camb_params(contract,lmax=2500))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
scratch=Path(__file__).resolve().parent
camb_root=Path(camb_reference.camb.__file__).resolve().parent.parent
sources={name:sha(camb_root/'fortran'/name) for name in ('results.f90','reionization.f90','recfast.f90','cmbmain.f90')}
sources.update({name:sha(scratch/name) for name in ('ccmbs_experimental_helper.py','ccmbs-recombination-case.py','ccmbs-reionization-case.py','ccmbs-experimental-reference-case.py')})
source_digest=hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest()
identity='camb:experimental:1.6.0:'+source_digest
fixture['reference_identity']=identity
fixture['provenance']['reference_identity']=identity
fixture['provenance']['reionization_model']='independent collapse-source integration'
fixture['experimental_inputs']={'origin':'temporary independent CAMB build','source_sha256':sources,'independent_scripts':{name:(scratch/name).read_text() for name in ('ccmbs_experimental_helper.py','ccmbs-recombination-case.py','ccmbs-reionization-case.py','ccmbs-experimental-reference-case.py')},'source_identity_sha256':source_digest,'stock_archive_sha256':sha(scratch/'ccmbs-camb-1.6.0.tar.gz'),'reference_harness_sha256':sha(Path(camb_reference.__file__)),'forutils_archive_sha256':sha(scratch/'ccmbs-forutils.tar.gz'),'experimental_binary_sha256':sha(camb_root/'camb/camblib.so'),'compiler':subprocess.check_output(['gfortran','--version'],text=True).splitlines()[0],'architecture':platform.machine(),'python_version':platform.python_version(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'recombination_table_sha256':sha(recombination),'reionization_table_sha256':sha(reionization),'photon_density':float(independent.get_Omega('photon')),'relativistic_density_method':'declared photon and effective species; independent Fermi-Dirac energy integral','dark_energy_treatment':'smooth declared background; perturbative stress disabled','source_transformations':['Override photon density before deriving massless neutrino radiation.','Use independently integrated ionization and matter-temperature tables.','Use the exact spherical Bessel function in the first interpolation cell for the experimental route.','Set the declared smooth dark-energy perturbative stress to zero.'],'physical_inputs_sha256':acceptance.diagnostics._canonical_sha256(acceptance.completion_physical_inputs(runtime)),'background_samples':{'redshift':z.tolist(),'H':ref_h.tolist(),'x_e':other['x_e'].tolist(),'T_b':other['T_b'].tolist(),'opacity':other['opacity'].tolist(),'neutrino_density':reference_neutrinos.tolist()},'background_checks':{'H_max_relative':H_error,'xe_max_absolute':xe_abs,'xe_peak_scaled':xe_scale,'recombination_xe_max_relative':xe_recombination,'matter_temperature_max_relative':temperature_error,'neutrino_density_max_relative':neutrino_error,'native_eta_samples':8192}}
fixture.pop('fixture_sha256')
fixture['fixture_sha256']=camb_reference.reference_fixture_sha256(fixture)
Path(output).write_text(json.dumps(fixture,sort_keys=True,separators=(',',':')))
print(json.dumps({'case':filename+':'+point,'reference_identity':identity,'sha256':fixture['fixture_sha256'],'background_checks':fixture['experimental_inputs']['background_checks'],'spectra_seconds':time.monotonic()-start}),flush=True)
