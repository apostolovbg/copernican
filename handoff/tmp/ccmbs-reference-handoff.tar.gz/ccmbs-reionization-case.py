import math, os, sys, tempfile
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.interpolate import PchipInterpolator
from copernican.lib import model_adapter, model_coder, model_spec_validator
from copernican.lib.likelihoods.cmb.runtime import background
from tests.project.lib import scientific_acceptance as acceptance, camb_reference
import ccmbs_experimental_helper
filename=sys.argv[1]
point=sys.argv[2] if len(sys.argv)>2 else 'initial'
with tempfile.TemporaryDirectory() as directory:
    validated=model_spec_validator.validate_and_cache_model(Path('copernican/models')/filename,directory)
    functions,data=model_coder.generate_callables(validated)
plugin=model_adapter.build_plugin(data,functions)
runtime=acceptance.completion_point_contract(plugin,point)
if acceptance.diagnostics._canonical_sha256(runtime['background']['reionization']) != '124f136ceaef2c0f0f2724ffafa3874b944c29963d7e31a58c0271fccc82254d':
 raise ValueError('Independent reference does not implement this reionization law')
if runtime['background'].get('recombination'):
 raise ValueError('Independent reference does not implement this recombination declaration')

physical=background._resolve_custom_cmb_physical_parameters(runtime)
os.environ['CCMBS_CAMB_REFERENCE_OMEGA_GAMMA']=str(physical.Omega_gamma0)
os.environ['CCMBS_CAMB_REFERENCE_PPF_DE']='1'
os.environ['CCMBS_CAMB_REFERENCE_RECOMB_TABLE']=sys.argv[3] + '-recombination.dat'
parameters=camb_reference._make_camb_params(acceptance.completion_reference_contract(runtime))
parameters.Reion.Reionization=False
reference=camb_reference.camb.get_background(parameters)
redshift=np.linspace(0,30,int(sys.argv[4]) if len(sys.argv)>4 else 6001)
thermal=reference.get_background_redshift_evolution(redshift,vars=('x_e','opacity'))
xfloor=PchipInterpolator(redshift,thermal['x_e'])
hubble=PchipInterpolator(redshift,reference.hubble_parameter(redshift)*1000/3.085677581e22)
helium=physical.YHe/(3.971425883512839*(1-physical.YHe))
nh0=thermal['opacity'][0]/thermal['x_e'][0]/(6.6524587321e-29*3.085677581e22)
alpha_h=4.309e-19/(1+0.6703)
alpha_he=1.54e-19
alpha_he2=4*4.309e-19*(0.5**-0.6166)/(1+0.6703*0.5**0.53)
electronvolt=1.602176634e-19
boltz=1.380649e-23
stellar=math.exp(-(24.587387-13.605693122994)*electronvolt/(boltz*5e4))
quasar=math.exp(-(54.417763-13.605693122994)*electronvolt/(boltz*1.5e5))
def solve(amplitude):
 def derivative(z,state):
  h,hs,hd,tau=state
  expansion=float(hubble(z)); a=1/(1+z); floor=float(xfloor(z)); nh=nh0*(1+z)**3
  electrons=max(floor+h+hs+2*hd,0)*nh
  collapse=math.exp(-1.686/(a+1e-6))
  gamma=10**amplitude*expansion*collapse; g2=gamma*collapse*quasar
  hdt=gamma*max(1-floor-h,0)-alpha_h*electrons*h
  hsdt=gamma*stellar*max(helium-hs-hd,0)-alpha_he*electrons*hs-g2*hs+alpha_he2*electrons*hd
  hddt=g2*hs-alpha_he2*electrons*hd
  tdt=(h+hs+2*hd)*nh*6.6524587321e-29*299792458
  return -np.array([hdt,hsdt,hddt,tdt])/((1+z)*expansion)
 result=solve_ivp(derivative,(30,0),np.zeros(4),method='BDF',rtol=float(sys.argv[5]) if len(sys.argv)>5 else 1e-9,atol=(float(sys.argv[5])*1e-3 if len(sys.argv)>5 else 1e-12),dense_output=True)
 if not result.success: raise ValueError(result.message)
 return result
def objective(amplitude): return solve(amplitude).y[3,-1]-float(runtime['param_map']['tau'])
amplitude=brentq(objective,4,9,xtol=1e-9)
solution=solve(amplitude)
extra=solution.sol(redshift)
ionization=xfloor(redshift)+extra[0]+extra[1]+2*extra[2]
np.savetxt(sys.argv[3] + '-reionization.dat',np.column_stack((redshift,ionization)),fmt='%.17e')
actual=background._build_custom_cmb_background_impl(runtime,physical,background._CustomCMBNumerics(eta_sample_count=8192))
z=np.linspace(0,25,251); eta=actual.eta_of_a(1/(1+z)); states=solution.sol(z)
independent=xfloor(z)+states[0]+states[1]+2*states[2]
expected=actual.x_e_of_eta(eta)
opacity=(1+z)**2*nh0*6.6524587321e-29*3.085677581e22*independent
actual_opacity=-actual.tau_dot_of_eta(eta)
if np.max(np.abs(independent-expected))/np.max(np.abs(independent))>0.005: raise ValueError('Independent reionization differs beyond its physical bound')
print('amplitude',amplitude,'tau',solution.y[3,-1])
print('xe_abs_error',np.max(np.abs(independent-expected)))
print('opacity_relative_error',np.max(np.abs(opacity/actual_opacity-1)))

for threshold in (0, 0.02, 0.1, 0.5):
 mask=independent>threshold
 index=np.flatnonzero(mask)[np.argmax(np.abs(opacity[mask]/actual_opacity[mask]-1))]
 print("opacity_above",threshold,"error",float(abs(opacity[index]/actual_opacity[index]-1)),"z",float(z[index]),"xe",float(independent[index]),"actual_xe",float(expected[index]))
