import math, os, sys, tempfile
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.interpolate import PchipInterpolator
from scipy.constants import G, c, h, k, m_e, e, sigma, pi
from copernican.lib import model_adapter, model_coder, model_spec_validator
from copernican.lib.likelihoods.cmb.runtime import background
from tests.project.lib import scientific_acceptance as acceptance, camb_reference
import ccmbs_experimental_helper

with tempfile.TemporaryDirectory() as directory:
 validated=model_spec_validator.validate_and_cache_model(Path('copernican/models') / sys.argv[1],directory)
 functions,data=model_coder.generate_callables(validated)
plugin=model_adapter.build_plugin(data,functions)
runtime=acceptance.completion_point_contract(plugin,sys.argv[2])
if acceptance.diagnostics._canonical_sha256(runtime['background']['reionization']) != '124f136ceaef2c0f0f2724ffafa3874b944c29963d7e31a58c0271fccc82254d':
 raise ValueError('Independent reference does not implement this reionization law')
if runtime['background'].get('recombination'):
 raise ValueError('Independent reference does not implement this recombination declaration')

physical=background._resolve_custom_cmb_physical_parameters(runtime)
os.environ['CCMBS_CAMB_REFERENCE_OMEGA_GAMMA']=str(physical.Omega_gamma0)
os.environ['CCMBS_CAMB_REFERENCE_PPF_DE']='1'
params=camb_reference._make_camb_params(acceptance.completion_reference_contract(runtime))
params.Reion.Reionization=False
reference=camb_reference.camb.get_background(params)
mpc=3.085677581e22
z_samples=np.geomspace(1,5001,12001)-1
H=PchipInterpolator(z_samples,reference.hubble_parameter(z_samples)*1000/mpc)
h0=physical.H0_km_s_Mpc*1000/mpc
nh0=physical.Omega_b0*3*h0*h0/(8*pi*G)*(1-physical.YHe)/1.673532838e-27
fhe=physical.YHe/(4*(1-physical.YHe))
today=physical.Tcmb_K
E_H=13.605693122994*e
E_He=24.587387*e
E_He2=54.417763*e
E_alpha=.75*E_H
lambda_alpha=h*c/E_alpha

def ratio(T,energy,weight=1):
 return math.exp(1.5*math.log(2*pi*m_e*k*T/(h*h))+math.log(weight)-energy/(k*T))

def helium_fraction(z,xh):
 T=today*(1+z); nh=nh0*(1+z)**3
 first=ratio(T,E_He,4); second=ratio(T,E_He2)
 def residual(helium):
  ne=max((xh+helium)*nh,1e-30)
  r1=first/ne; r2=second/ne
  return helium-fhe*(r1+2*r1*r2)/(1+r1+r1*r2)
 return brentq(residual,0,2*fhe,xtol=1e-14)

def saha_hydrogen(z):
 T=today*(1+z); nh=nh0*(1+z)**3; r=ratio(T,E_H)/nh
 def residual(xh):
  he=helium_fraction(z,xh); b=he+r
  return xh-2*r/(b+math.sqrt(b*b+4*r))
 return brentq(residual,0,1,xtol=1e-13)

zswitch=brentq(lambda z:saha_hydrogen(z)-.99,500,2500,xtol=1e-8)
def derivative(z,state):
 xh=float(state[0]); a=1/(1+z); temp=today*(1+z) if z>=150 else today*(1+z)**2/151
 tr=max(temp/1e4,1e-4)
 alpha=1.14*4.309e-19*tr**-0.6166/(1+.6703*tr**.53)
 beta2=alpha*ratio(temp,E_H/4); betac=beta2*math.exp(-E_alpha/(k*temp))
 nh=nh0*(1+z)**3; hubble=float(H(z)); neutral=max(1-xh,1e-12)
 peebles=lambda_alpha**3/(8*pi*hubble)
 C=(1+peebles*8.22458*nh*neutral)/(1+peebles*(8.22458+beta2)*nh*neutral)
 xe=xh+helium_fraction(z,xh)
 return [-C*(betac*neutral-nh*alpha*xe*xh)/((1+z)*hubble)]
sol=solve_ivp(derivative,(zswitch,0),[.99],method='Radau',rtol=float(sys.argv[5]) if len(sys.argv)>5 else 1e-9,atol=(float(sys.argv[5])*1e-3 if len(sys.argv)>5 else 1e-12),dense_output=True)
if not sol.success: raise ValueError(sol.message)
z=np.asarray([25,100,300,600,800,1000,1100,1200,1400,1600,2000,2500],dtype=float)
xh=np.array([float(sol.sol(v)[0]) if v<zswitch else saha_hydrogen(v) for v in z])
xe=np.array([v+helium_fraction(zz,v) for zz,v in zip(z,xh)])
actual=background._build_custom_cmb_background_impl(runtime,physical,background._CustomCMBNumerics(eta_sample_count=4096))
other=actual.x_e_of_eta(actual.eta_of_a(1/(1+z)))
print('zswitch',zswitch,'independent_xe',xe.tolist())
print('relative_difference',(other/xe-1).tolist())
if np.max(np.abs(other/xe-1))>0.001: raise ValueError('Independent recombination differs beyond its physical bound')
table_z=np.geomspace(1,100001,int(sys.argv[4]) if len(sys.argv)>4 else 20001)-1
table_h=np.asarray([float(sol.sol(value)[0]) if value<zswitch else saha_hydrogen(value) for value in table_z])
table_xe=np.asarray([value+helium_fraction(redshift,value) for redshift,value in zip(table_z,table_h)])
table_temp=np.where(table_z>=150,today*(1+table_z),today*(1+table_z)**2/151)
np.savetxt(sys.argv[3] + '-recombination.dat',np.column_stack((table_z,table_xe,table_temp)),fmt='%.17e')
print('table_written',len(table_z),float(table_xe[-1]),flush=True)
