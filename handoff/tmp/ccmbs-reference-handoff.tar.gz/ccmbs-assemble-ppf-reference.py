import json
import pathlib
import sys
import numpy
from tests.project.lib import camb_reference, scientific_acceptance
root=pathlib.Path.cwd()
case=sys.argv[1]
filename,point=case.split(':')
base=pathlib.Path('/private/tmp') / ('ccmbs-ppf-'+filename.removesuffix('.yml')+'-'+point)
load=lambda label: json.loads(pathlib.Path(str(base)+'-'+label+'.json').read_text())
tables={label:{name:numpy.loadtxt(str(base)+'-'+label+'-'+name+'.dat') for name in ('recombination','reionization')} for label in ('coarse','fine')}
requirement=json.loads((root/'tests/project/fixtures/ccmbs_completion_contract.json').read_text())['cases'][case]
reference,updated=camb_reference.build_experimental_completion_reference(load('coarse'),load('fine'),requirement,input_tables=tables)
scientific_acceptance._validate_completion_reference(reference,reference['fixture_sha256'],reference['contract'],case,expected_identity=updated['reference_identity'])
scientific_acceptance._validate_experimental_refinement(reference,updated)
pathlib.Path(str(base)+'-assembled.json').write_text(json.dumps({'reference':reference,'requirement':updated},sort_keys=True,separators=(',',':')))
print(json.dumps({'case':case,'ell_count':len(reference['ell_values']),'digest':reference['fixture_sha256'],'historical_ell_count':len(requirement['ells'])}))
